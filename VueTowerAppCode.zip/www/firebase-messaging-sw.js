importScripts('./build/sw-toolbox.js');
importScripts('https://www.gstatic.com/firebasejs/3.5.2/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/3.5.2/firebase-messaging.js');


var config = {
    apiKey: "AIzaSyA9VzyGk5udMRYhY4cBJTheleiUJuYlcFA",
    authDomain: "vue-tower.firebaseapp.com",
    databaseURL: "https://vue-tower.firebaseio.com",
    projectId: "vue-tower",
    storageBucket: "vue-tower.appspot.com",
    messagingSenderId: "758015936740"
};
firebase.initializeApp(config);


/* firebase.initializeApp({
   // get this from Firebase console, Cloud messaging section
   messagingSenderId: "587368411111"
}); */

const messaging = firebase.messaging();
messaging.onMessage((data) => {
    console.log('data from push notifiction', data);
});

messaging.setBackgroundMessageHandler((payload) => {
    console.log('[firebase-messaging-sw.js] Received background message ', payload);

    console.log('data from payload', payload);
    // Customize notification here
    const notificationTitle = 'Background Message Title';
    const notificationOptions = {
        body: 'Background Message body.',
        icon: 'assets/imgs/icon.png'
    };

    return self.registration.showNotification(notificationTitle, notificationOptions);
});