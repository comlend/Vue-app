import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FbprofilePage } from './fbprofile';

@NgModule({
  declarations: [
    FbprofilePage,
  ],
  imports: [
    IonicPageModule.forChild(FbprofilePage),
  ],
})
export class FbprofilePageModule {}
